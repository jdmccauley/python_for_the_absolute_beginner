setup.py
pause